package crud;
package br.com.viagem.main;

import java.util.Scanner;

import dao.PassagemDAO;
import model.Passagem;
import dao.ClienteDAO;
import model.Cliente;
import dao.PermissoesDAO;
import model.Permissoes;

public class Main {

	public static void main(String[] args) {
		
		int op;
		Scanner tc = new Scanner(System.in);

		ClienteDAO clienteDAO = new ClienteDAO();
		PassagemDAO passagemDAO = new PassagemDAO();
		PermissoesDAO permissoesDAO = new PermissoesDAO();
		Cliente contato = new Cliente();
		Passagem destino = new Passagem();
		Permissoes permissoes = new Permissao();

		  do {
			  System.out.println("Menu de viagens!\n");
			  System.out.println("1 - Cadastrar cliente \n2 - Remover cliente \n3 - Visualizar clientes \n4 - Cadastrar passagem \n5 - Remover passagem \n6 - Visualizar passagem \n7 - Cadastrar Passagem \n8 - Visualizar passagens \n9 - Remover passagem \n10 - Sair \n");
			  op = Integer.parseInt(tc.nextLine());

			  switch(op) {

			  	case 1:
			  		System.out.println("Nome:");
					contato.setNome(tc.nextLine());
					System.out.println("Celular:");
					contato.setCelular(tc.nextLine());
					System.out.println("E-mail:");
					contato.setEmail(tc.nextLine());
					clienteDAO.save(contato);
			  		break;

			  	case 2:
			  		System.out.println("Escolha o id do cliente que será removido: ");
					clienteDAO.removeCliente(Integer.parseInt(tc.nextLine()));
			  		break;

			  	case 3:
					clienteDAO.listaCliente();
			  		break;

			  	case 4:
			 		System.out.println("Pais:");
					destino.setPais(tc.nextLine());
			 		System.out.println("Cidade:");
					destino.setCidade(tc.nextLine());
			 		System.out.println("Valor:");
					destino.setValor(Integer.parseInt(tc.nextLine()));
					destinoDAO.save(destino);
			  		break;

			  	case 5:
			  		System.out.println("Escolha o id do destino que será removido: ");
					destinoDAO.removeDestino(Integer.parseInt(tc.nextLine()));
					break;

			  	case 6:
					destinoDAO.listaDestino();
			  		break;

			  	case 7:
			 		System.out.println("id_cliente:");
					viagem.setId_cliente(Integer.parseInt(tc.nextLine()));
			 		System.out.println("id_destino:");
					viagem.setId_destino(Integer.parseInt(tc.nextLine()));
					System.out.println("Data do voo:");
					viagem.setDatavoo(tc.nextLine());
					System.out.println("Data da compra:");
					viagem.setDatacompra(tc.nextLine());
					viagemDAO.save(viagem);
					break;

			  	case 8:
					viagemDAO.listaViagem();
			  		break;

			  	case 9:
			  		System.out.println("Escolha o id da viagem que será removida: ");
					viagemDAO.removeViagem(Integer.parseInt(tc.nextLine()));
					break;

			  	case 10:
			  		System.out.println("Programa finalizado!");
			  		break;
			  }
		  } while(op != 10);


		tc.close();
	}


}
