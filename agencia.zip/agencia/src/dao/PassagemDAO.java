package dao;

public class PassagemDAO {
	public void save(Passagem contato){

		String sql = "INSERT INTO Passagem(pais, cidade, valor, id_passagem) VALUES (?, ?, ?, ?)";

		Connection conn = null;
		PreparedStatement pstm = null;

		try {
			conn = ConnectionFactory.createConnectionToMySQL();
			pstm = (PreparedStatement) conn.prepareStatement(sql);
			pstm.setString(1, contato.getPais());
			pstm.setString(2, contato.getCidade());
			pstm.setFloat(3, contato.getValor());
			pstm.setInt(4, contato.getId_passagem());

			pstm.execute();

			System.out.println("Registro salvo com sucesso!\n");

		}catch (Exception e){
			e.printStackTrace();

		} finally {

			try {

				if(pstm!=null) {
					pstm.close();
				}

				if(conn!=null) {
					conn.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	// Listar os destinos
	public void listaDestino() {
		String sql = "SELECT * FROM Passagem";

		Connection conn = null;
		PreparedStatement pstm = null;

		try {
			conn = ConnectionFactory.createConnectionToMySQL();
		    pstm = conn.prepareStatement(sql);
		    ResultSet result = pstm.executeQuery();

			lista(result);

		} catch(Exception ex) {
			ex.printStackTrace();
		} finally {
			try {

				if(pstm!=null) {
					pstm.close();
				}

				if(conn!=null) {
					conn.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	protected void lista(ResultSet result) throws SQLException {
		while(result.next()) {
			System.out.println("\n" + String.format("Id %d", result.getInt("id_passagem")));
			System.out.println(String.format("Pais %s ", result.getString("pais")));
			System.out.println(String.format("Cidade %s ", result.getString("cidade")));
			System.out.println(String.format("Valor %.2f ", result.getFloat("valor"))+ "\n");
		}

	}

	// Remover destino
	public void removeDestino(Integer id) {
		String sql = "DELETE FROM Destino WHERE id_passagem = ?";

		Connection conn = null;
		PreparedStatement pstm = null;

		try {
			conn = ConnectionFactory.createConnectionToMySQL();
		    pstm = conn.prepareStatement(sql);

		    String sql2 = "SELECT id_destino FROM Passagem WHERE id_destino = ?";
		    PreparedStatement pstm2 = conn.prepareStatement(sql2);
			pstm2.setInt(1, id);
			ResultSet result = pstm2.executeQuery();
		    if(result.next()) remove(pstm, id);
		    else System.out.println("Passagem não encontrada");

		} catch(SQLException ex) {
			System.out.println(ex.getMessage());
		} finally {
			try {

				if(pstm!=null) {
					pstm.close();
				}

				if(conn!=null) {
					conn.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	protected void remove(PreparedStatement pstm, Integer id) throws SQLException {
		pstm.setInt(1, id);
		boolean temErro = pstm.execute();

		if(!temErro) System.out.println("Passagem removida com sucesso\n");
	}

	// Altera passagem
public void alteraDestino(Passagem passagem) {

		String sql = "UPDATE Destino SET pais = ?, cidade = ?, valor = ? "
				+ "WHERE id_destino = ?";

		Connection conn = null; 
		PreparedStatement pstm = null;

		try {
			conn = ConnectionFactory.createConnectionToMySQL();
		    pstm = conn.prepareStatement(sql);

		    String sql2 = "SELECT id_passagem FROM Passagem WHERE id_passagem = ?";
		    PreparedStatement pstm2 = conn.prepareStatement(sql2);
			pstm2.setInt(1, destino.getId_destino());
			ResultSet result = pstm2.executeQuery();
		    if(result.next()) atualiza(pstm, destino);
		    else System.out.println("Insira um id valido.");


		} catch(Exception ex) {
			ex.printStackTrace();
		} finally {
			try {

				if(pstm!=null) {
					pstm.close();
				}

				if(conn!=null) {
					conn.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
protected void atualiza(PreparedStatement pstm, Passagem contato) throws SQLException {
	pstm.setString(1, contato.getPais());
	pstm.setString(2, contato.getCidade());
	pstm.setFloat(3, contato.getValor());
	pstm.setInt(4, contato.getId_destino());
	boolean temErro = pstm.execute();

	if(!temErro) System.out.println("Passagem alterada com sucesso!\n");
}

	
}
